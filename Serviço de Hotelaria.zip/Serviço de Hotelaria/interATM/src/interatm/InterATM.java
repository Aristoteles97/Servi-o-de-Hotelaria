/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interatm;

import java.util.Scanner;

/**
 *
 * @author manuelernesto
 */
public class InterATM {

    static ClasseWS http = new ClasseWS();

    static void criarConta() {

        System.out.print("Digite o nome:");
        String nome = new Scanner(System.in).nextLine();
        System.out.print("Digite o Sobrenome:");
        String sobrenome = new Scanner(System.in).nextLine();
        System.out.print("Digite o BI:");
        String bi = new Scanner(System.in).nextLine();
        System.out.print("Digite o numero:");
        String numero = new Scanner(System.in).nextLine();
        System.out.print("Digite o Saldo Inicial:");
        String saldo = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/ATM/webresources/ATM/ATM/addConta/" + nome + "/" + sobrenome + "/" + bi + "/" + numero + "/" + saldo;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }

    }

    static void consultarSaldo() {

        System.out.print("Digite o numero:");
        String numero = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/ATM/webresources/atm/atm/consultar/" + numero;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void levantamento() {

        System.out.print("Digite o numero:");
        String numero = new Scanner(System.in).nextLine();
        System.out.print("Digite o Valor:");
        String valor = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/ATM/webresources/atm/atm/levantar/" + numero + "/" + valor;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void transferencia() {

        System.out.print("Digite a sua conta:");
        String conta_origem = new Scanner(System.in).nextLine();
        System.out.print("Digite a conta de destino:");
        String conta_destino = new Scanner(System.in).nextLine();
        System.out.print("Digite o Valor:");
        String valor = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/ATM/webresources/ATM/ATM/transferencia/" + conta_origem + "/" + conta_destino + "/" + valor;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }
    
    static void deposito() {

        System.out.print("Digite a sua conta:");
        String conta = new Scanner(System.in).nextLine();
        System.out.print("Digite o Valor:");
        String valor = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/ATM/webresources/ATM/ATM/depositar/"+conta+"/"+valor;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void menu() {
        System.out.println("=================== Menu Princiapl ==============");
        System.out.println("=1 Levantamento ====================");
        System.out.println("=2 Consultar Saldo =================");
        System.out.println("=3 Transferencia ===================");
        System.out.println("=4 Deposito ========================");
        System.out.println("=5 Criar Conta =====================");
        System.out.println("=0 Sair ============================");
        System.out.println("=================================================");
    }

    public static void main(String[] args) throws Exception {

        int opcoes;

        do {

            menu();
            opcoes = new Scanner(System.in).nextInt();

            switch (opcoes) {
                case 1:
                    levantamento();
                    break;
                case 2:
                    consultarSaldo();
                    break;
                case 3:
                    transferencia();
                    break;
                case 4:
                    deposito();
                    break;
                case 5:
                    criarConta();
                    break;

            }

        } while (opcoes != 0);

    }

}