package interatm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class ClasseWS {
 
	private final String USER_AGENT = "Mozilla/5.0";

 
	public void sendGet(String url) throws Exception {

 
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
 
		// opcional o padrao é GET
		con.setRequestMethod("GET");
 
		//adiconar cabeçalho de requisição 
		con.setRequestProperty("User-Agent", USER_AGENT);
 
		
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                
		String inputLine;
                
		StringBuffer response = new StringBuffer();
 
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
 
		System.err.println(response.toString());
 
	}
 
	
}
