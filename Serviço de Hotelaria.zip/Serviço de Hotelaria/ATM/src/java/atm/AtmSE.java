/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm;

import Modelo.Titular;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;

/**
 * REST Web Service
 *
 * @author MH
 */
@Path("ATM")
public class AtmSE {

    public static  List<Titular> titulares = new ArrayList<>();
    
    @Context
    private UriInfo context;

    /**
     * Creates a new instance of AtmSE
     */
    public AtmSE() {
    }

    /**
     * Retrieves representation of an instance of atm.AtmSE
     * @return an instance of java.lang.String
     */
  
    
    
    // Criar conta
   
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("ATM/addConta/{nome}/{sobrenome}/{bi}/{numero}/{saldo}")
    public String addConta (@PathParam("nome") String nome,
                              @PathParam("sobrenome") String sobrenome, 
                              @PathParam("bi") String bi,
                              @PathParam("numero") String numero,
                              @PathParam("saldo") float saldo){
        
        Titular t = new Titular();
    
        t.setNome(nome);
        t.setSobrenome(sobrenome); 
        t.setBi(bi); 
        t.setNumero(numero); 
        t.setSaldo(saldo); 
   
        titulares.add(t);
        
        return "Conta criada com sucesso";
    }
    
    
    // Mostrar Contas
  
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("ATM/mostrarContas/")
    public String mostrarConta() {
        return titulares.toString();
    }
    
    
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("ATM/depositar/{numero}/{valor}")
    public String depositar(@PathParam("numero") String numero,
            @PathParam("valor") float valor) {

        int i = 0;
        for (int p = 0; p < titulares.size(); p++) {
            if (titulares.get(p).getNumero().equalsIgnoreCase(numero)) {
                titulares.get(p).setSaldo(titulares.get(p).getSaldo() + valor);
                i = p;
            }
        }

        return "Deposito Efectudacom com sucesso na Conta do: "
                + titulares.get(i).getNome();
    }

    
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("ATM/levantar/{numero}/{valor}")
    public String levantar(@PathParam("numero") String numero,
            @PathParam("valor") float valor) {

        for (int p = 0; p < titulares.size(); p++) {
            if (titulares.get(p).getNumero().equalsIgnoreCase(numero)) {

                if (titulares.get(p).getSaldo() >= valor) {

                    titulares.get(p).setSaldo(titulares.get(p).getSaldo() - valor);

                    return "Levantamento Efectuda com sucesso na Conta do: "
                            + titulares.get(p).getNome();

                } else {
                    return "Saldo Insuficiente";
                }
            }
        }

        return "";
    }
    
/*    
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("atm/consultar/{numero}")
    public String consultar(@PathParam("numero") String numero) {

        String texto = "";

//        for (int p = 0; p < titulares.size(); p++) {
//
//            if (titulares.get(p).getNumero().equals(numero)) {
//                texto = "Nome: " + titulares.get(p).getNome() + " " 
//                        + titulares.get(p).getSobrenome()
//                        + "-\tSaldo:" + titulares.get(p).getSaldo();
//            }
//        }
        DAO dao = new DAO();
        Titular titular = dao.consultarSaldo(numero);
        texto = "Nome: " + titular.getNome() + " "
                + titular.getSobrenome()
                + "-\tSaldo:" + titular.getSaldo();
        
        return texto;
   
    }

    */
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("ATM/transferencia/{conta_origem}/{conta_destino}/{valor}")
    public String transferencia(@PathParam("conta_origem") String conta_origem,
            @PathParam("conta_destino") String conta_destino,
            @PathParam("valor") float valor) {

        for (int p = 0; p < titulares.size(); p++) {
            if (titulares.get(p).getNumero().equalsIgnoreCase(conta_origem)) {

                for (int i = 0; i < titulares.size(); i++) {
                    if (titulares.get(i).getNumero().equalsIgnoreCase(conta_destino)) {
                        if (titulares.get(p).getSaldo() >= valor) {

                            titulares.get(p).setSaldo(titulares.get(p).getSaldo() - valor);
                            titulares.get(i).setSaldo(titulares.get(i).getSaldo() + valor);

                            return "Transferencia Efectuda com sucesso";

                        } else {
                            return "Saldo Insuficiente";
                        }
                    }
                }

            }
        }

        return "";
    }
    
    

    /**
     * PUT method for updating or creating an instance of AtmSE
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Consumes("application/json")
    public void putJson(String content) {
    }
}
