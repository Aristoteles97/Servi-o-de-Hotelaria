/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelNguebo;

import Cliente.Cliente;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Graciano Designer
 */
@Path("hotelNguebo")
public class HotelNguebo {

    public static List<Cliente> clientes = new ArrayList<>();

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of HOTELResource
     */
    public HotelNguebo() {
    }

    /**
     * Retrieves representation of an instance of Hotel.HOTELResource
     *
     * @return an instance of java.lang.String
     */
    // Criar a conta de um novo cliente
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/novoCliente/{nome}/{sobrenome}/{telefone}/{conta}/{saldo}")
    public String novoCliente(@PathParam("nome") String nome,
            @PathParam("sobrenome") String sobrenome,
            @PathParam("telefone") String telefone,
            @PathParam("conta") String conta,
            @PathParam("saldo") float saldo) {

        Cliente c = new Cliente();

        c.setNome(nome);
        c.setSobrenome(sobrenome);
        c.setTelefone(telefone);
        c.setConta(conta);
        c.setSaldo(saldo);

        clientes.add(c);

        return "Cliente adicionado com sucesso";
    }

    // Mostrar Clientes 
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/mostrarClientes/")
    public String mostrarClientes() {
        return clientes.toString();
    }

    // consultar o saldo
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/consultar/{conta}")
    public String consultar(@PathParam("conta") String conta) {

        String texto = "";

        for (int p = 0; p < clientes.size(); p++) {

            if (clientes.get(p).getConta().equals(conta)) {
                texto = "Nome: " + clientes.get(p).getNome() + " "
                        + clientes.get(p).getSobrenome()
                        + " -\tSaldo: " + clientes.get(p).getSaldo();
            }
        }

        return texto;
    }

    // adicionar saldo a conta
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/adicionarValor/{conta}/{valor}")
    public String addSaldo(@PathParam("conta") String conta,
            @PathParam("valor") float valor) {

        int i = 0;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {
                clientes.get(p).setSaldo(clientes.get(p).getSaldo() + valor);
                i = p;
            }
        }

        return "Deposito Efectudo com sucesso na Conta de "
                + clientes.get(i).getNome();
    }

    // reservar quarto vip
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/quartoVIP/{conta}")
    public String quartoVip(@PathParam("conta") String conta) {

        float valor = 20000;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {

                if (clientes.get(p).getSaldo() >= valor) {

                    clientes.get(p).setSaldo(clientes.get(p).getSaldo() - valor);

                    return "Quarto reservado com sucesso por "
                            + clientes.get(p).getSobrenome();

                } else {
                    return "Seu saldo não é suficiente!";
                }
            }
        }

        return "";
    }

    // reservar quarto normal
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/quartoNormal/{conta}")
    public String quartoNormal(@PathParam("conta") String conta) {

        float valor = 15000;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {

                if (clientes.get(p).getSaldo() >= valor) {

                    clientes.get(p).setSaldo(clientes.get(p).getSaldo() - valor);

                    return "Quarto reservado com sucesso por "
                            + clientes.get(p).getSobrenome();

                } else {
                    return "Seu saldo não é suficiente!";
                }
            }
        }

        return "";
    }

    // serviço de refeição
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/refeicao/{conta}")
    public String refeicao(@PathParam("conta") String conta) {

        float valor = 5000;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {

                if (clientes.get(p).getSaldo() >= valor) {

                    clientes.get(p).setSaldo(clientes.get(p).getSaldo() - valor);

                    return "Serviço requisitado com sucesso por "
                            + clientes.get(p).getSobrenome();

                } else {
                    return "Seu saldo não é suficiente!";
                }
            }
        }

        return "";
    }

    // serviço lavandaria
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/lavandario/{conta}")
    public String lavandario(@PathParam("conta") String conta) {

        float valor = 2000;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {

                if (clientes.get(p).getSaldo() >= valor) {

                    clientes.get(p).setSaldo(clientes.get(p).getSaldo() - valor);

                    return "Serviço requisitado com sucesso por "
                            + clientes.get(p).getSobrenome();

                } else {
                    return "Seu saldo não é suficiente!";
                }
            }
        }

        return "";
    }

    // serviço transporte
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    @Path("hotelNguebo/transporte/{conta}")
    public String transporte(@PathParam("conta") String conta) {

        float valor = 500;
        for (int p = 0; p < clientes.size(); p++) {
            if (clientes.get(p).getConta().equalsIgnoreCase(conta)) {

                if (clientes.get(p).getSaldo() >= valor) {

                    clientes.get(p).setSaldo(clientes.get(p).getSaldo() - valor);

                    return "Serviço requisitado com sucesso "
                            + clientes.get(p).getSobrenome();

                } else {
                    return "Seu saldo não é suficiente!";
                }
            }
        }

        return "";
    }

    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of HOTELResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
