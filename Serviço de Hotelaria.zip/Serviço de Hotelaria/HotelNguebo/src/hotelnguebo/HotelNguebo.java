/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelnguebo;

import java.util.Scanner;

/**
 *
 * @author Graciano Designer
 */
public class HotelNguebo {

    static ClasseWS http = new ClasseWS();

    static void novoCliente() {

        System.out.print("Digite o nome:");
        String nome = new Scanner(System.in).nextLine();
        System.out.print("Digite o Sobrenome:");
        String sobrenome = new Scanner(System.in).nextLine();
        System.out.print("Digite o numero de telefone:");
        String telefone = new Scanner(System.in).nextLine();
        System.out.print("Digite o numero da conta:");
        String conta = new Scanner(System.in).nextLine();
        System.out.print("Digite o Saldo Inicial:");
        String saldo = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/novoCliente/" + nome + "/" + sobrenome + "/" + telefone + "/" + conta + "/" + saldo;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }

    }

    static void quartoVIP() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/quartoVIP/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void quartoNormal() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/quartoNormal/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void saldo() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/consultar/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void addSaldo() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();
        System.out.print("Digite o valor:");
        String valor = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/adicionarValor/" + conta + "/" + valor;

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void refeicao() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/refeicao/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void lavandaria() {

        System.out.print("Digite o numero da sua conta:");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/lavandaria/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    static void transporte() {

        System.out.print("Digite o numero da sua conta: ");
        String conta = new Scanner(System.in).nextLine();

        String url = "http://localhost:8080/hotelNguebo/webresources/hotelNguebo/hotelNguebo/transporte/" + conta + "/";

        try {
            http.sendGet(url);
        } catch (Exception ex) {
            System.out.println("ERRO:" + ex.getMessage());
        }
    }

    // Menu da aplicação cliente
    static void menu() {
        System.out.println("=================== Menu Princiapl ==============");
        System.out.println("=1 Criar Conta =====================");
        System.out.println("=2 Consultar Saldo =====================");
        System.out.println("=3 Adicionar Saldo =====================");
        System.out.println("=4 Reservar um Quarto =====================");
        System.out.println("=5 Outros Serviço =====================");
        System.out.println("=0 Sair ============================");
        System.out.println("=================================================");
    }

    // Menu reservar um quarto
    static void quarto() {
        System.out.println("=================== Quartos ==============");
        System.out.println("=1 VIP =====================");
        System.out.println("=2 Normal =====================");
        System.out.println("=0 Voltar ============================");
        System.out.println("=================================================");
    }

    static void outrosServicos() {
        System.out.println("=================== Outros Serviços ==============");
        System.out.println("=1 Refeição =====================");
        System.out.println("=2 Lavandaria =====================");
        System.out.println("=3 Transporte =====================");
        System.out.println("=0 Voltar ============================");
        System.out.println("=================================================");
    }

    public static void main(String[] args) throws Exception {

        int opcoes;
        int quar;
        int ser;
        do {

            menu();
            opcoes = new Scanner(System.in).nextInt();

            switch (opcoes) {

                // opção de criar conta
                case 1:
                    novoCliente();
                    break;

                case 2:
                    saldo();
                    break;
                case 3:
                    addSaldo();
                    break;

                // opção de reservar um quarto   
                case 4:
                    do {

                        quarto();
                        quar = new Scanner(System.in).nextInt();
                        switch (quar) {
                            case 1:
                                quartoVIP();
                                break;
                            case 2:
                                quartoNormal();
                                break;

                        }
                    } while (quar != 0);

                case 5:
                    do {

                        outrosServicos();
                        ser = new Scanner(System.in).nextInt();
                        switch (ser) {
                            case 1:
                                refeicao();
                                break;
                            case 2:
                                lavandaria();
                                break;
                            case 3:
                                transporte();
                                break;

                        }
                    } while (ser != 0);

            }

        } while (opcoes != 0);

    }
}
